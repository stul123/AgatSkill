<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>AgatSkill</title>
    <link rel="stylesheet" href="/css/style.css" />
    <style>
        .header_stud {
            position: fixed;
        }
        .main_stud_answers {
            margin-left: 264px;
        }
    </style>
    <?php
    session_start();
     ?>
</head>

<body>
    <div class="admin_block">
        <header class="header_stud">
            <div class="logo"><img src="/img/black_logo,.svg" alt="logo">
                <h2>AgatSkill</h2>
            </div>
            <div class="profile">
            <?php
                $db = new SQLite3('../db/db.db');
                $stmt = $db->prepare('SELECT * FROM users WHERE user_id = :user_id');
                $stmt->bindValue(':user_id', $_SESSION['user_id'], SQLITE3_INTEGER);
                $resultv2 = $stmt->execute();
                $mainuser = $resultv2->fetchArray(SQLITE3_ASSOC);
                
                ?>
                <img src="<?php echo $mainuser["avatar"];?>" class="teacherava" alt="Avatar">
                <p><?php echo $mainuser["name"] . ' ' . $mainuser["surname"];?></p>
           
            </div>
            <div class="nav">
                <p>Навигация</p>
                <div class="list">
                    <a href=""></a>
                    <img src="/img/hat.svg" alt="hat">
                    <p><a href="/teacher/">Список студентов</a></p>
                </div>
                <div class="list">
                    <img src="/img/Book 2.svg" alt="Book">
                    <p><a href="/create_lesson/">Создать урок</a></p>
                </div>
                <div class="list">
                    <img src="/img/histogram.svg" alt="histogram">
                    <p><a href="/lesson_list/">Список уроков</a></p>
                </div>
                <div class="list active">
                    <img src="/img/bookmark.svg" alt="bookmark">
                    <p><a href="/answers/">Просмотр ответов</a></p>
                </div>
                <div class="list">
                    <img src="/img/paper clip.svg" alt="paper clip">
                    <p><a href="/summary_table">Сводная таблица</a></p>
                </div>
            </div>
        </header>
        <main class="main_stud_answers">
            <div class="title-block-bum">
                <div class="title_box">
                    <div class="main_title">
                        <h2>Просмотр ответов</h2>
                        <p></p>
                    </div>
                </div>
            </div>
            <div class="first_block">
                <div class="card">
                    <div class="name">
                        <img src="/img/member1.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member11.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member4.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member10.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member12.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member13.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member1.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member2.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
                <div class="card">
                    <div class="name">
                        <img src="/img/member14.svg" alt="avatar">
                        <h2>Анастасия Ландашева</h2>
                    </div>
                    <div class="card_text">
                        <h2>Урок №1. Введение в Дизайн</h2>
                        <h3>Дата выполнения: 20.01.2023</h3>
                        <p>Здравствуйте, Людмила Анатольевна, вот мое домашнее задание! Хочу спросить Вас на следующем уроке кое-что :( Извините за задержку!</p>
                    </div>
                    <button class="btn"><a href="/answer">Подробнее</a></button>
                </div>
            </div>
        </main>
    </div>
</body>

</html>