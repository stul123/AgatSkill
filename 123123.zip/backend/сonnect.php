<?php

$database_file = "./db.db";
$db = new SQLite3($database_file);

?>
