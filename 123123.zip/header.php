    <header>
        <div class="header_con">
            <div class="left">
                <div class="logo">
                    <img src="/img/logo.svg" alt="logo">
                    <p>AgatSkill</p>
                </div>
                <a href="/courses" class="check_courses">
                    <img src="/img/Book 2.svg" alt="Book 2"> Просмотр уроков
                </a>
            </div>
            <div class="profile">
                <a href="/profile" class="profile_block">
                    <img src="/img/profile.png" alt="profile"> Личный профиль
                </a>
            </div>
        </div>
    </header>