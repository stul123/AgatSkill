    <footer>
        <div class="footer_con">
            <div class="logo_con">
                <div class="logo">
                    <img src="/img/logo.svg" alt="logo">
                    <p>AgatSkill</p>
                </div>
                <p class="text_under_logo">Знания - ключ к воротам возможностей: открой их с нами!</p>
            </div>
            <div class="info_con">
                <div class="list">
                    <p class="title">О AgatSkill</p>
                    <a href="#">О нас</a>
                    <a href="#">Центр карьеры</a>
                    <a href="#">Отзывы</a>
                    <a href="#">О платформе</a>
                </div>
                <div class="list">
                    <p class="title">Контакты</p>
                    <a href="tel:88002228649">8 (800) 222-86-49</a>
                    <a href="tel:+74994449036">+7 499 444 90 36</a>
                </div>
            </div>
        </div>
    </footer>